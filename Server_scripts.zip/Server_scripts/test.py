__author__ = 'hengam'
dirGeneral ="/home/hengam/PycharmProjects/PdbChains/0Grammer/server/example/"
import math
import os

rsa = 5
win = 5

#grammer_name = "4states"
#gr = "simple"
grammer_name = "11states"
gr = "complex"

algorithm = "posterior-viterbi-sum"
alg = "post"
#algorithm = "viterbi"
#alg = "vit"


for i in range(0 , 10):
    command = "biocrf -test -m example/models/model_rsa%d_w%d_%s/model%d.txt -w 0 -d %s -o example/prediction/prediction_%s_rsa%d_w%d_%s/test%d.pred  example/0pssm_dataset/pssm_rsa%d_w%d/test%d_%dse_w%d_pssm.txt" %(rsa , win , gr , i , algorithm , alg , rsa , win , gr , i ,rsa , win , i , rsa , win)
    print command
    os.system(command)

