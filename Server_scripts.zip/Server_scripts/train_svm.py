__author__ = 'hengam'

import math
import os

rsa = 16
win = 17

#grammer_name = "4states"
#gr = "simple"

grammer_name = "11states"
gr = "complex"

j=80
sigma = 0.05
w= 0
a = 3

for i in range(0 , 10):
#    os.system("export LD_LIBRARY_PATH=/home/saeideh/boost_1_40_0/stage/lib/")
    command = "biocrf -train -g example/grammer/grammer.%s -j %d -s %.2f -m example/models/model_rsa%d_w%d_%s/model%d.txt -w %d -a %d example/0pssm_dataset/pssm_rsa%d_w%d/train%d_%dse_w%d_pssm.txt" %(grammer_name , j , sigma , rsa , win , gr , i , w , a  , rsa ,win, i , rsa , win)
    print(command)
    os.system(command)


